package com.softlayer.api;

/** Asynchronous service interface extended by individual async service interfaces */
public interface ServiceAsync extends Maskable, ResultLimitable {
}
