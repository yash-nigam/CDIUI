package com.softlayer.api.http;

/** Base interface for all accepted HTTP credentials */
public interface HttpCredentials {
}
